
public class Book {

    // Fill the code here
    
    private String bookName;
    private int bookPrice;
    private String authorName;
    
    public void setBookName(String bookName)
    {
        this.bookName = bookName;
    }
    public String getBookName()
    {
        return this.bookName;
    }
    
    
    public void setBookPrice(int bookPrice)
    {
        this.bookPrice = bookPrice;
    }
    public int getBookPrice()
    {
        return this.bookPrice;
    }
    
    
    public void setAuthorName(String authorName)
    {
        this.authorName = authorName;
    }
    public String getAuthorName()
    {
        return authorName;
    }

}
