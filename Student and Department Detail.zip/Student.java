
public class Student {

    // Fill the code here
    
    private int sid;
    private String sname;
    private Department department;
    
    public void setSid(int sid)
    {
        this.sid = sid;
    }
    public void setSname(String sname)
    {
        this.sname =sname;
    }
    public void setDepartment(Department department)
    {
        this.department = department;
    }
    
    public int getSid()
    {
        return sid;
    }
    public String getSname()
    {
        return sname;
    }
    public Department getDepartment()
    {
        return department;
    }


}
