import java.util.*;

public class VolumeCalculator {

    // Fill the code here
    
    public double calculateVolume(double radius, double height)
    {
        return (3.14 * radius * radius * height);
    }
    
    public double calculateVolume(int length, int breadth, int height)
    {
       return  (length * breadth * height);
    }

    
}
