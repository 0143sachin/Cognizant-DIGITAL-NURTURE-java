public class BusTicket
{
    private int ticketNo;
    private float ticketPrice;
    private float totalAmount;
    private Person person;
    public void setPerson(Person person)
    {
        this.person=person;
    }
    public Person getPerson()
    {
        return person;
    }
    public void setTicketNo(int ticketNo)
    {
        this.ticketNo=ticketNo;
    }
    public void setTicketPrice(float ticketPrice)
    {
        this.ticketPrice=ticketPrice;
    }
    public void setTotalAmount(float totalAmount)
    {
        this.totalAmount= totalAmount;
    }
    public int getTicketNo()
    {
        return ticketNo;
    }
    public float getTicketPrice()
    {
        return ticketPrice;
    }
    public float getTotalAmount()
    {
        return totalAmount;
    }
    public void calculateTotal()
    {
        if(person.getAge()<=15)
        {
            setTotalAmount(ticketPrice/2);
        }
        else if(person.getAge()>=60)
        {
            setTotalAmount(ticketPrice*75/100);
        }
        else if(person.getGender()=='f'||person.getGender()=='F')
        {
            setTotalAmount(ticketPrice*90/100);
        }
        else
        {
            setTotalAmount(ticketPrice);
        }
    }
}