
public class Employee {

    // Fill the code here
    private int employeeId;
    private String employeeName;
    private double salary;
    private double netSalary;
    public void setEmployeeId(int employeeId){
        this.employeeId = employeeId;
    }
    public void setEmployeeName(String employeeName){
        this.employeeName = employeeName;
    }
    public void setSalary(double salary){
        this.salary = salary;
    }
    public void setNetSalary(double netSalary){
        this.netSalary = netSalary;
    }
    public int getEmployeeId(){
        return this.employeeId;
    }
    public String getEmployeeName(){
        return this.employeeName;
    }
    public double getSalary(){
        return this.salary;
    }
    public double getNetSalary(){
        return this.netSalary;
    }
    public void calculateNetSalary(int pfpercentage){
        this.netSalary = this.salary-(this.salary*pfpercentage/100);
    }


}
